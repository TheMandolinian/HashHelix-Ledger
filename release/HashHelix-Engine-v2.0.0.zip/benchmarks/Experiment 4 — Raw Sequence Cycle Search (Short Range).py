"""
Experiment 4 — Raw Sequence Cycle Search (Short Range)
Phase 2: Will it blow up at scale?

Scope: n < 1e6
Method: Floyd + Brent cycle detection on augmented WDTP state.
"""

import os
import sys
import math
import time

# -------------------------------------------------------
# Fix Python path — ensure repo root is importable
# -------------------------------------------------------
REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

# -------------------------------------------------------
# Instrumentation imports
# -------------------------------------------------------
try:
    import research.tools.instrumentation.instrumentation_tools as inst
except Exception as e:
    raise ImportError(
        "Required instrumentation tools not found at "
        "research/tools/instrumentation/instrumentation_tools.py. "
        f"Original import error: {e}"
    )

# Flexible mapping: grab whatever functions exist
floyd_detect = inst.floyd_cycle_detection
brent_detect = inst.brent_cycle_detection

if floyd_detect is None or brent_detect is None:
    raise ImportError(
        "Could not find Floyd/Brent detectors in instrumentation_tools.py. "
        "Expected names: floyd_detect/floyd and brent_detect/brent."
    )

# -------------------------------------------------------
# WDTP + NER (immutable)
# -------------------------------------------------------
TWO_PI = 2.0 * math.pi

def wdtp_next(n: int, a_prev: int):
    phi = (a_prev + math.pi / n) % TWO_PI
    a_n = math.floor(n * math.sin(phi)) + 1
    return a_n, phi

def F(state):
    n, a, phi = state
    n_next = n + 1
    a_next, phi_next = wdtp_next(n_next, a)
    return (n_next, a_next, phi_next)

# -------------------------------------------------------
# Runner
# -------------------------------------------------------
def run_short_raw_cycle_search(N_limit=1_000_000):
    a1 = 1
    phi1 = (a1 + math.pi) % TWO_PI   # phi_1 formal
    s0 = (1, a1, phi1)

    print(f"Running Experiment 4 short-range raw cycle search up to n<{N_limit:,}")
    print("Running Floyd detector...")
    t0 = time.time()
    floyd_result = floyd_detect(F, s0, max_iter=N_limit)
    t1 = time.time()
    print(f"Floyd completed in {t1 - t0:.2f}s")

    if floyd_result and floyd_result.get("has_cycle"):
        return {"method": "floyd", **floyd_result}

    print("Running Brent detector...")
    t2 = time.time()
    brent_result = brent_detect(F, s0, max_iter=N_limit)
    t3 = time.time()
    print(f"Brent completed in {t3 - t2:.2f}s")

    if brent_result and brent_result.get("has_cycle"):
        return {"method": "brent", **brent_result}

    return None


if __name__ == "__main__":
    result = run_short_raw_cycle_search()

    print("\n--- RESULT ---")
    if result is None:
        print("No true cycle detected in raw sequence for short range.")
    else:
        print("TRUE CYCLE DETECTED!")
        for key, value in result.items():
            print(f"{key}: {value}")
